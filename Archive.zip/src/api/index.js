// import data from './data.json';

// export default () => {
//   return data;
// }