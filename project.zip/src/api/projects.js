import pimg1 from '../images/project/1.jpg';
import pimg2 from '../images/project/2.jpg';
import pimg3 from '../images/project/3.jpg';
import pimg4 from '../images/project/4.jpg';
import pimg5 from '../images/project/5.jpg';
import pimg6 from '../images/project/6.jpg';


import p2img1 from '../images/project-single/1.jpg'
import p2img2 from '../images/project-single/2.jpg'
import p2img3 from '../images/project-single/3.jpg'
import p2img4 from '../images/project-single/4.jpg'
import p2img5 from '../images/project-single/5.jpg'
import p2img6 from '../images/project-single/6.jpg'






const Projects = [
    {
        id: '1',
        title: 'Heart Institure',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Heart-Institure',
        pimg1: pimg1,
        pSimg: p2img1,
        location: '7 Lake Street,London',
        date: '15 Dec 2024',
    },
    {
        id: '2',
        title: 'Orthopaedics Center',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Orthopaedics-Center',
        pimg1: pimg2,
        pSimg: p2img2,
        location: '7 Lake Street,London',
        date: '15 Dec 2024',
    },
    {
        id: '3',
        title: 'Neurology Services',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Neurology-Services',
        pimg1: pimg3,
        pSimg: p2img3,
        location: '7 Lake Street,London',
        date: '15 Dec 2024',
    },
    {
        id: '4',
        title: 'Quality Therapy',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Quality-Therapy',
        pimg1: pimg4,
        pSimg: p2img4,
        location: '7 Lake Street,London',
        date: '15 Dec 2024',
    },
    {
        id: '5',
        title: 'Pediatric Surgery',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Neurology-Services',
        pimg1: pimg5,
        pSimg: p2img5,
        location: '7 Lake Street,London',
        date: '15 Dec 2024',
    },
    {
        id: '6',
        title: 'Surgical',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Surgical-Services',
        pimg1: pimg6,
        pSimg: p2img6,
        location: '7 Lake Street,London',
        date: '15 Dec 2024',
    },




]
export default Projects;






